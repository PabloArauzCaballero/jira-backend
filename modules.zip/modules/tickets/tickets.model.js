const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
  const Ticket = sequelize.define(
    "ticket",
    {
      id_ticket: {
        type: DataTypes.BIGINT,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
      },

      nombre: {
        type: DataTypes.STRING(150),
        allowNull: false,
      },

      descripcion: {
        type: DataTypes.TEXT,
        allowNull: true,
      },

      // Sin defaultValue: PostgreSQL aplica DEFAULT 'MEDIA'.
      prioridad: {
        type: DataTypes.STRING(30),
      },

      // Sin defaultValue: PostgreSQL aplica DEFAULT 'PENDIENTE'.
      status: {
        type: DataTypes.STRING(30),
      },

      // Sin defaultValue: PostgreSQL aplica DEFAULT NOW().
      fecha_creacion: {
        type: DataTypes.DATE,
      },

      // Sin defaultValue: PostgreSQL aplica DEFAULT 'ACTIVO'.
      estado_registro: {
        type: DataTypes.STRING(20),
      },

      actualizado_en: {
        type: DataTypes.DATE,
        allowNull: true,
      },

      user_id_creacion: {
        type: DataTypes.BIGINT,
        allowNull: true,
        references: {
          model: "usuarios",
          key: "id_usuario",
        },
        onUpdate: "CASCADE",
        onDelete: "SET NULL",
      },

      user_id_modificacion: {
        type: DataTypes.BIGINT,
        allowNull: true,
        references: {
          model: "usuarios",
          key: "id_usuario",
        },
        onUpdate: "CASCADE",
        onDelete: "SET NULL",
      },

      // Sin defaultValue: PostgreSQL aplica DEFAULT 1.
      version: {
        type: DataTypes.INTEGER,
      },
    },
    {
      tableName: "ticket",
      freezeTableName: true,
      timestamps: false,
    }
  );

  Ticket.associate = (models) => {
    Ticket.belongsTo(models.Usuario, {
      foreignKey: "user_id_creacion",
      targetKey: "id_usuario",
      as: "usuarioCreacion",
    });

    Ticket.belongsTo(models.Usuario, {
      foreignKey: "user_id_modificacion",
      targetKey: "id_usuario",
      as: "usuarioModificacion",
    });

    Ticket.hasMany(models.TicketAction, {
      foreignKey: "id_ticket",
      sourceKey: "id_ticket",
      as: "acciones",
    });

    Ticket.hasMany(models.TicketAcceptanceCriteria, {
      foreignKey: "id_ticket",
      sourceKey: "id_ticket",
      as: "criteriosAceptacion",
    });

    Ticket.hasMany(models.ProyectoAsignacion, {
      foreignKey: "id_ticket",
      sourceKey: "id_ticket",
      as: "asignaciones",
    });
  };

  return Ticket;
};
